class Echo():
    def doit(self, value):
        #print "Hello World"
        return value
